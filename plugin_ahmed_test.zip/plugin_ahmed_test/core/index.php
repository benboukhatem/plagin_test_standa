<?php //Silence is golden

